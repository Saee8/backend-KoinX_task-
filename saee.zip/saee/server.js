const express = require("express");
const app = express();
require("dotenv").config();
const axios = require("axios");
const bodyParser = require("body-parser");
const connectDB = require("./DataBase/db");

const EtherRateModal = require("./DataBase/models/etherRate");
const updateTransactions = require("./routes/updateTransactions");

connectDB();

const port = process.env.PORT ?? 3000;

// middleware
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(bodyParser.json());

// test
app.get("/", (req, res) => {
  console.log("called");
  res.status(200).send("Hello World");
});

// Insert latest transactions
app.use("/transactions", updateTransactions);

const getUpdatesOfInr = () => {
  try {
    setInterval(async () => {
      const etherRate = new EtherRateModal();
      const response = await axios.get(
        "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=inr"
      );
      etherRate.rate = response.data.ethereum.inr;
      etherRate.currency = "INR";
      etherRate.updated_date = new Date();
      etherRate.save((err, data) => {
        if (data) {
          console.log("Updated the latest price of ethereum");
        } else {
          console.log(err);
        }
      });
    }, 600000);
  } catch (e) {
    console.log(e);
  }
};

getUpdatesOfInr();

// Execution
app.listen(port, () => {
  console.log(`Server listening on port http://localhost:${port}/`);
});
