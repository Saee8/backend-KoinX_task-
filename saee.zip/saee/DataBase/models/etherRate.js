const mongoose = require("mongoose");

const etherRateSchema = new mongoose.Schema({
  rate: {
    type: String,
    required: true,
    trim: true,
  },
  currency: {
    type: String,
    required: true,
  },
  updated_date: {
    type: Date,
    required: true,
  },
});

const EtherRateModal = mongoose.model("EtherRate", etherRateSchema);

module.exports = EtherRateModal;
