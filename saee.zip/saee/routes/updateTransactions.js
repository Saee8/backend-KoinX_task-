const express = require("express");
const axios = require("axios");

let router = express.Router();
const TransactionModel = require("../DataBase/models/transaction");

router.route("/update").get(async (req, res) => {
  const { address, apiKey } = req.body;
  try {
    const data = await axios.get(
      `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&page=1&offset=10&sort=asc&apikey=${apiKey}`
    );

    console.log(data.data.message);
    if (data.data.message) {
      data.data.result.map((item) => {
        var transactionModel = new TransactionModel();
        transactionModel.address = address;
        transactionModel.blockNumber = item.blockNumber;
        transactionModel.timeStamp = item.timeStamp;
        transactionModel.hash = item.hash;
        transactionModel.nonce = item.nonce;
        transactionModel.blockHash = item.blockHash;
        transactionModel.transactionIndex = item.transactionIndex;
        transactionModel.from = transactionModel.from;
        transactionModel.to = transactionModel.to;
        transactionModel.value = item.value;
        transactionModel.gas = item.gas;
        transactionModel.gasPrice = item.gasPrice;
        transactionModel.isError = transactionModel.isError;
        transactionModel.txreceipt_status = item.txreceipt_status;
        transactionModel.input = item.input;
        transactionModel.contractAddress = item.contractAddress;
        transactionModel.cumulativeGasUsed = item.cumulativeGasUsed;
        transactionModel.gasUsed = item.gasUsed;
        transactionModel.confirmations = item.confirmations;
        transactionModel.methodId = item.methodId;
        transactionModel.functionName = item.functionName;
        transactionModel.save();
      });
      res.send("Transactions Updated in the database").status(200);
    } else {
      res.status(400).send("Bad Request");
    }
  } catch (e) {
    console.log(e);
    res.status(400).send("Bad Request");
  }
});

module.exports = router;
